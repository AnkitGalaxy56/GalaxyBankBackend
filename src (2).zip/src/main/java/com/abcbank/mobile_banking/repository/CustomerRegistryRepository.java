
package com.abcbank.mobile_banking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abcbank.mobile_banking.entity.CustomerRegistry;

public interface CustomerRegistryRepository
        extends JpaRepository<CustomerRegistry, String> {
}
